# Copyright 2024 Code17 GmbH
#
# This file is licensed under the Elastic License 2.0 (ELv2).
# Refer to the LICENSE.txt file in the root of the repository
# for details.
#


"""
Base class. Should not ever be directly initialized!
"""

import numbers
from abc import ABC, abstractmethod
from dataclasses import dataclass
from typing import Any, ClassVar, Dict, Optional, Set

import numpy as np

from getml.utilities.formatting import _SignatureFormatter

from .validation import Validator

# --------------------------------------------------------------------


@dataclass
class _FeatureLearner(ABC):
    """
    Base class. Should not ever be directly initialized!
    """

    _supported_params: ClassVar[Set]

    def __post_init__(self) -> None:
        type(self)._supported_params = set(vars(self).keys())
        for param in self._supported_params:
            setattr(type(self), param, Validator(param))

    # ----------------------------------------------------------------

    def __eq__(self, other: object) -> bool:
        """Compares the current instance with another one.

        Returns:
            Indicating whether the current instance and `other` are the same.
        """

        # Allow for in comparing for feature_learner names
        if isinstance(other, str):
            return other == self.type

        if not isinstance(other, _FeatureLearner):
            raise TypeError(
                """A feature learning algorithm can only
                compared to another feature learning algorithm!"""
            )

        # Check whether both objects have the same number of instance
        # variables.
        if len(set(self.__dict__.keys())) != len(set(other.__dict__.keys())):
            return False

        for kkey in self.__dict__:
            if kkey not in other.__dict__:
                return False

            # Take special care when comparing numbers.
            if isinstance(self.__dict__[kkey], numbers.Real):
                if not np.isclose(self.__dict__[kkey], other.__dict__[kkey]):
                    return False

            elif self.__dict__[kkey] != other.__dict__[kkey]:
                return False

        return True

    # ----------------------------------------------------------------

    def __repr__(self) -> str:
        return str(self)

    # ----------------------------------------------------------------

    def __setattr__(self, name: str, value: Any) -> None:
        if name in self.__dataclass_fields__:  # pylint: disable=E1101
            super().__setattr__(name, value)
        else:
            raise AttributeError(
                f"Instance variable '{name}' is not supported in {self.type}."
            )

    # ----------------------------------------------------------------

    def __str__(self) -> str:
        sig = _SignatureFormatter(self)
        return sig._format()

    # ----------------------------------------------------------------

    def _getml_deserialize(self) -> Dict[str, Any]:
        # To ensure the getML can handle all keys, we have to add
        # a trailing underscore.
        self_dict = self.__dict__
        encoding_dict = dict()

        for kkey in self_dict:
            encoding_dict[kkey + "_"] = self_dict[kkey]

        encoding_dict["type_"] = self.type

        return encoding_dict

    # ---------------------------------------------------------------

    @property
    def type(self) -> str:
        return type(self).__name__

    # ---------------------------------------------------------------

    @abstractmethod
    def validate(self, params: Optional[Dict[str, Any]] = None) -> None:
        pass
